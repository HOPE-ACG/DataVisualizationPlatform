create
    definer = root@localhost procedure del_data_mq()
BEGIN
	TRUNCATE TABLE sensor_mq9;
	TRUNCATE TABLE sensor_mq135;
END;

