create definer = root@localhost event del_fun_dhds on schedule
    every '30' DAY
        starts '2020-10-15 00:00:00'
    on completion preserve
    enable
    do
    CALL del_data_dhds();

