create
    definer = root@localhost procedure del_data_dhds()
BEGIN
	TRUNCATE TABLE sensor_dht11;
	TRUNCATE TABLE sensor_ds18b20;
END;

